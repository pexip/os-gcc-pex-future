(* Copyright (C) 2005, 2006 Free Software Foundation, Inc. *)
(* This file is part of GNU Modula-2.

GNU Modula-2 is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the Free
Software Foundation; either version 2, or (at your option) any later
version.

GNU Modula-2 is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with gm2; see the file COPYING.  If not, write to the Free Software
Foundation, 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA. *)
MODULE subrange11 ;

PROCEDURE outer;

CONST
   beforeinner = 1000 + 1 ;

   PROCEDURE inner;
   TYPE
      ind1 = [-200..200];
   CONST
      low = ind1(-200);
   BEGIN
   END inner;

VAR
   a: array ;
TYPE
   ind0 = [-100..100];
   array = ARRAY [low..0] OF CHAR ;
CONST
   low = ind0(-100);


BEGIN
END outer;

BEGIN
   outer
END subrange11.
